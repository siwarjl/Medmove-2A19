#ifndef QRCODEGENERATEDEMO_H
#define QRCODEGENERATEDEMO_H


class qrcodegeneratedemo
{
public:
    qrcodegeneratedemo();
};

#endif // QRCODEGENERATEDEMO_H
