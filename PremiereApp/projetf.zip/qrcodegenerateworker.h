#ifndef QRCODEGENERATEWORKER_H
#define QRCODEGENERATEWORKER_H


class qrcodegenerateworker
{
public:
    qrcodegenerateworker();
};

#endif // QRCODEGENERATEWORKER_H
