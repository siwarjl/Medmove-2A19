  #include "arduino1.h"

/*arduino1::arduino1()
{

}*/
